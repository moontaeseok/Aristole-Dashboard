document.addEventListener("DOMContentLoaded", () => {
    const data = typeof AristotData !== 'undefined' ? AristotData : null;
    if(!data) return;

    // 1. Metrics 카운트업
    const animateValue = (id, target) => {
        let curr = 0;
        const el = document.getElementById(id);
        const inc = target / 50;
        const intv = setInterval(() => {
            curr += inc;
            if(curr >= target) {
                curr = target;
                clearInterval(intv);
            }
            el.innerHTML = Math.floor(curr) + (id === 'val-depth' ? '<span class="sm">%</span>' : '');
        }, 20);
    };

    animateValue("val-records", data.record_count);
    animateValue("val-depth", data.logic_depth);
    animateValue("val-unique", data.unique_words);

    // 2. 명언 롤링 
    const quoteEl = document.getElementById("quote-display");
    let qIdx = 0;
    const rotateQuote = () => {
        quoteEl.style.opacity = 0;
        setTimeout(() => {
            quoteEl.innerText = `"${data.key_quotes[qIdx]}"`;
            quoteEl.style.opacity = 1;
            qIdx = (qIdx + 1) % data.key_quotes.length;
        }, 500);
    };
    rotateQuote();
    setInterval(rotateQuote, 5000);

    // 모달창 데이터 사전 (상세 설명) - 철학, 문헌, 어휘, 노드 등 모두 통합
    const detailedInfo = {
        // 주요 학문
        "형이상학 (Metaphysics)": "형이상학(Metaphysics)은 존재 그 자체에 대한 탐구입니다. 아리스토텔레스는 이를 가장 근원적인 '제1철학'이라 불렀으며, 사물을 이루는 본질과 원인, 그리고 궁극적인 목적점인 '부동의 원동자(Prime Mover)'를 규명합니다.",
        "니코마코스 윤리학 (Ethics)": "인간 삶의 궁극적 목적을 '행복(Eudaimonia)'으로 정의합니다. 행복을 달성하기 위해서는 이성에 따르는 덕성스러운 활동이 필요하며, 양극단을 피하는 '중용(Mesotes)'의 지혜와 탁월함(Arete)을 습관화해야 한다고 역설합니다.",
        "정치학 (Politics)": "개인의 윤리를 국가와 공동체 차원으로 확장한 학문입니다. '인간은 본성적으로 참된 의미의 정치적 동물(Zoon Politikon)이다'라는 명제 아래, 모범적인 폴리스(Polis) 국가의 구조와 시민의 역할을 깊이 있게 다룹니다.",
        "수사학 (Rhetoric)": "타인을 논리적으로 설득하기 위한 최적의 방법을 탐구하는 기술입니다. 화자의 인품을 나타내는 에토스(Ethos), 논리적 증명인 로고스(Logos), 청중의 감정인 파토스(Pathos)의 세 가지 설득 수단을 체계화했습니다.",
        "시학 (Poetics)": "예술과 문학의 본질이 현실 세계의 '모방(Mimesis)'에 있다고 평합니다. 특히 비극을 통해 관객이 두려움과 연민을 느끼고 감정이 정화되는 '카타르시스(Catharsis)' 개념을 확립한 최초의 문예 이론 도서입니다.",
        
        // 지표 정보 (Metrics Cards)
        "총찰 문헌 분류망": "📜 [주요 분석 문헌 목록]\n1. 형이상학 (Metaphysica)\n2. 니코마코스 윤리학 (Ethica Nicomachea)\n3. 오르가논 (Organon) - 논리학 저술군\n4. 영혼에 관하여 (De Anima)\n5. 정치학 (Politica)\n\n* 총 8,420권 분량의 파피루스/스크롤 데이터 환산 완료. 모든 데이터가 데이터베이스에 캐싱되었습니다.",
        "철학적 심도 통계": "🧠 [아리스토텔레스 논리 분석 개요]\n문헌 내에서 연역법(Syllogism) 구조와 귀납법(Epagoge)의 사용 빈도를 분석하여 측정된 지적 밀도입니다.\n\n- 삼단논법 패턴 감지율: 상위 3%\n- 핵심 전제(Premise) 도달 깊이: 96/100\n- 모순 없는 학문적 정합성: A+ 등급",
        "어휘 및 텍스트 다양성": "🗣️ [발견된 핵심 고대 헬라어 어휘]\n- 에우다이모니아 (Eudaimonia: 행복)\n- 아레테 (Arete: 탁월함)\n- 텔로스 (Telos: 궁극적 목적)\n- 프로네시스 (Phronesis: 실천적 지혜)\n- 힐레 (Hyle: 질료) / 에이도스 (Eidos: 형상)\n\n* 총 1,543개의 고전 그리스어 고유 어휘 패턴 분류 완료.",

        // 존재론 (Ontology Nodes)
        "실체 (Substance)": "아리스토텔레스 철학에서 가장 근본적인 존재 단위(Ousia)입니다. 다른 것의 속성이 되지 않고 스스로 존재하는 주체이며, 형상(Eidos)과 질료(Hyle)의 결합물입니다.",
        "형상 (Eidos)": "사물을 그 사물이게끔 만드는 본질이자 형태입니다. 조각가에게 있어 '머리속의 조각상 디자인'에 해당합니다.",
        "질료 (Hyle)": "형상을 받아들여 구체적인 사물이 될 수 있는 잠재성이나 물리적 재료입니다. 가능태(Dynamis)의 상태에 머무릅니다.",
        "운동 (Kinesis)": "가능태에서 현실태(Energeia)로 변해가는 과정 그 자체를 뜻합니다.",
        "원동자 (Prime Mover)": "우주의 모든 사물을 목적을 향해 움직이게 만드는 궁극적 원인이지만, 자신은 전혀 움직이지 않는 완전한 현실태, 즉 신(God)적 존재입니다.",
        "영혼 (Psyche)": "생명체의 본질이자 형상입니다. 식물의 영혼, 동물의 영혼을 거쳐 오직 인간만이 사유를 관장하는 이성적 영혼을 지닌다고 보았습니다.",
        "이성 (Logos)": "오직 인간만이 지닌 사유와 언어의 능력입니다. 이를 통해 진리를 파악하고 옳고 그름에 대한 윤리적인 판단을 내릴 수 있습니다."
    };

    // 모달창 조작 로직
    const overlay = document.getElementById("detail-modal");
    const mTitle = document.getElementById("modal-title");
    const mBody = document.getElementById("modal-body");

    const openModal = (title, keyTitle) => {
        mTitle.innerText = title;
        mBody.innerText = detailedInfo[keyTitle || title] || "상세 정보가 존재하지 않습니다.";
        overlay.classList.add("active");
    };

    document.getElementById("close-modal").addEventListener("click", () => overlay.classList.remove("active"));
    overlay.addEventListener("click", (e) => {
        if(e.target === overlay) overlay.classList.remove("active");
    });

    // 3. 존재론적 관계망 생성 및 노드 클릭 이벤트 바인딩
    const ontoGraph = document.getElementById("ontology-graph");
    ontoGraph.innerHTML = "";
    data.ontology.forEach(rel => {
        const row = document.createElement("div");
        row.className = "onto-row";
        
        // 각각의 노드를 생성 (클릭가능)
        const sourceNode = document.createElement("div");
        sourceNode.className = "onto-node";
        sourceNode.innerText = rel.source;
        sourceNode.addEventListener("click", () => openModal(rel.source));

        const arrowLine = document.createElement("div");
        arrowLine.className = "onto-line";

        const targetNode = document.createElement("div");
        targetNode.className = "onto-node";
        targetNode.innerText = rel.target;
        targetNode.addEventListener("click", () => openModal(rel.target));

        row.appendChild(sourceNode);
        row.appendChild(arrowLine);
        row.appendChild(targetNode);
        ontoGraph.appendChild(row);
    });

    // 4. 강성 점유율 (Branches) 생성 및 클릭 이벤트
    const branchesList = document.getElementById("branches-list");
    branchesList.innerHTML = "";
    data.core_branches.forEach(branch => {
        const item = document.createElement("div");
        item.className = "branch-item clickable";
        item.innerHTML = `
            <div class="b-header">
                <span class="b-name">${branch.label} <span class="click-hint">[클릭 열람]</span></span>
                <span class="b-val">${branch.percentage}%</span>
            </div>
            <div class="b-track">
                <div class="b-fill" style="width: 0%; transition: width 1.5s ease-out"></div>
            </div>
        `;
        item.addEventListener("click", () => openModal(branch.label));
        branchesList.appendChild(item);
    });

    // 지표(Metrics) 카드 클릭 이벤트 바인딩
    document.getElementById("card-records").addEventListener("click", () => openModal("총찰 문헌 분석 데이터", "총찰 문헌 분류망"));
    document.getElementById("card-depth").addEventListener("click", () => openModal("아리스토텔레스 철학적 심도", "철학적 심도 통계"));
    document.getElementById("card-unique").addEventListener("click", () => openModal("어휘 및 형태소 메타데이터", "어휘 및 텍스트 다양성"));

    setTimeout(() => {
        const fills = document.querySelectorAll(".b-fill");
        fills.forEach((fill, i) => fill.style.width = `${data.core_branches[i].percentage}%`);
    }, 400);
});
