// Auto-Generated Aristotle Enriched Payload
const AristotData = {
  status: "deep_analysis",
  parsed_percent: 100,
  record_count: 8420,
  unique_words: 1543,
  logic_depth: 96,
  harmony_score: 88,
  core_branches: [
    { label: "형이상학 (Metaphysics)", percentage: 88 },
    { label: "니코마코스 윤리학 (Ethics)", percentage: 76 },
    { label: "정치학 (Politics)", percentage: 65 },
    { label: "수사학 (Rhetoric)", percentage: 54 },
    { label: "시학 (Poetics)", percentage: 41 }
  ],
  key_quotes: [
    "인간은 본성적으로 국가(Polis)를 구성하는 동물이다.",
    "탁월함(Arete)은 하나의 행위가 아니라 길러지는 습관이다.",
    "모든 예술과 학문은 어떤 '선(Good)'을 목적 삼는다."
  ],
  ontology: [
    { source: "실체 (Substance)", target: "형상 (Eidos)" },
    { source: "실체 (Substance)", target: "질료 (Hyle)" },
    { source: "운동 (Kinesis)", target: "원동자 (Prime Mover)" },
    { source: "영혼 (Psyche)", target: "이성 (Logos)" }
  ]
};